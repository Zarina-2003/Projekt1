from tkinter import *
from scapy.all import *
from scapy.layers.inet import IP, TCP, UDP, ICMP

def block_traffic(ip):
    send(IP(dst=ip)/ICMP(type=3, code=3))

def packet_callback(packet):
    if packet.haslayer(IP):
        log_text.insert(END, f"IP Source: {packet[IP].src}, IP Destination: {packet[IP].dst}, Protocol: {packet[IP].proto}\n")
        if len(packet) > 1500:
            log_text.insert(END, "Suspiciously large packet detected!\n")
        if packet.haslayer(TCP):
            ports = (packet[TCP].sport, packet[TCP].dport)
            log_text.insert(END, f"TCP Source Port: {ports[0]}, TCP Destination Port: {ports[1]}\n")
            if 80 in ports:
                log_text.insert(END, "HTTP traffic detected!\n")
        elif packet.haslayer(UDP):
            ports = (packet[UDP].sport, packet[UDP].dport)
            log_text.insert(END, f"UDP Source Port: {ports[0]}, UDP Destination Port: {ports[1]}\n")
        elif packet.haslayer(ICMP):
            log_text.insert(END, f"ICMP Type: {packet[ICMP].type}, ICMP Code: {packet[ICMP].code}\n")
            if packet[ICMP].type == 3 and packet[ICMP].code == 3:
                log_text.insert(END, "ICMP Destination Unreachable message received!\n")
                block_traffic(packet[IP].dst)

def start_sniffing():
    sniff(iface=interface_entry.get(), prn=packet_callback, store=0)

root = Tk()
root.title("Packet Sniffer")

Label(root, text="Interface:").pack(pady=10)
interface_entry = Entry(root).pack(pady=10)
Button(root, text="Start Sniffing", command=start_sniffing).pack(pady=10)
log_text = Text(root, width=50, height=20).pack(pady=10)
Button(root, text="Clear Log", command=lambda: log_text.delete(1.0, END)).pack(pady=10)

root.mainloop()
